//
//  JOINStoriesSDK.h
//  JOINStoriesSDK
//
//  Created by Maxime Lignereux on 15/11/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for JOINStoriesSDK.
FOUNDATION_EXPORT double JOINStoriesSDKVersionNumber;

//! Project version string for JOINStoriesSDK.
FOUNDATION_EXPORT const unsigned char JOINStoriesSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JOINStoriesSDK/PublicHeader.h>


